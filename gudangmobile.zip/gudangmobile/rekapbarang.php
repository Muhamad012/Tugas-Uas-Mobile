<!DOCTYPE html>
<html>
<head>
<title>Rekap Barang - SIM Gudang</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body{
  background-color: #f9f9f9ff;
}

#myInput {
  background-image: url('assets/images/line-chart.gif');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
</style>
</head>
<body>

<div class="container mt-5">

<table id="myTable">
  <tr class="header">
    <th style="width:auto;">Nomor Pengiriman</th>
    <th style="width:auto;">Nama Barang</th>
    <th style="width:auto;">Nama Penerima</th>
    <th style="width:auto;">Nomor Telepon</th>
    <th style="width:auto;">Alamat</th>
    <th style="width:auto;">Jumlah Kiriman</th>
    <th style="width:auto;">Berat</th>
    <th style="width:auto;">Pembayaran</th>
    <th style="width:auto;">Tanggal</th>
    <th style="width:auto;">Deskripsi</th>
  </tr>
<?php include('koneksi.db.php');
$sql="select * from barang inner join transaksi on barang.Namabarang=transaksi.NamaBarang";
$q=mysqli_query($koneksi,$sql);
$r=mysqli_fetch_array($q);
if (!empty($r)) {
do { ?>
  <tr>
    <td><?php echo $r['NomorPengiriman'];?></td>
    <td><?php echo $r['NamaBarang'];?></td>
    <td><?php echo $r['NamaPenerima'];?></td>
    <td><?php echo $r['NomorTelepon'];?></td>
    <td><?php echo $r['AlamatPenerima'];?></td>
    <td><?php echo $r['JumlahKiriman'];?></td>
    <td><?php echo $r['Berat'];?></td>
    <td><?php echo $r['Pembayaran'];?></td>
    <td><?php echo $r['Tanggal'];?></td>
    <td><?php echo $r['Deskripsi'];?></td>
  </tr>
<?php } while($r=mysqli_fetch_array($q)); 
} else {
  echo "<h2>Barang tidak ada !</h2>";
}?> 
  
</table><br> 

<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

</div>
</body>
</html>

<?php
include "koneksi.db.php";

$NomorPengiriman = filter_var($_POST['NomorPengiriman'],FILTER_SANITIZE_STRING);
$NamaBarang = filter_var($_POST['NamaBarang'],FILTER_SANITIZE_STRING);
$NamaPenerima = filter_var($_POST['NamaPenerima'],FILTER_SANITIZE_STRING);
$NomorTelepon = filter_var($_POST['NomorTelepon'],FILTER_SANITIZE_STRING);
$AlamatPenerima = filter_var($_POST['AlamatPenerima'],FILTER_SANITIZE_STRING);
$JumlahKiriman = filter_var($_POST['JumlahKiriman'],FILTER_SANITIZE_STRING);
$Berat = filter_var($_POST['Berat'],FILTER_SANITIZE_STRING);
$Pembayaran = filter_var($_POST['Pembayaran'],FILTER_SANITIZE_STRING);
$Tanggal = filter_var($_POST['Tanggal'],FILTER_SANITIZE_STRING);
$Deskripsi = filter_var($_POST['Deskripsi'],FILTER_SANITIZE_STRING);

// Insert data ke database
$sql = "INSERT INTO transaksi (NomorPengiriman, NamaBarang, NamaPenerima, NomorTelepon, AlamatPenerima, JumlahKiriman, Berat, Pembayaran, Tanggal, Deskripsi)
VALUES ('$NomorPengiriman', '$NamaBarang', '$NamaPenerima', '$NomorTelepon', '$AlamatPenerima', '$JumlahKiriman', '$Berat', '$Pembayaran', '$Tanggal', '$Deskripsi')";

if ($koneksi->query($sql) === TRUE) {
    $sqlbarang="update barang set JumlahKiriman=JumlahStok+".$Jumlah." where NamaBarang='".$NamaBarang."'";
    echo "terkirim";
} else if ($koneksi->errno == 1062) {
    $sqlbarang="update barang set JumlahKiriman=JumlahStok-".$Jumlah." where NamaBarang='".$NamaBarang."'";
    echo "Nomors";
} else {
    echo "Error: " . $sql . "<br>" . $koneksi->error;
}
?>

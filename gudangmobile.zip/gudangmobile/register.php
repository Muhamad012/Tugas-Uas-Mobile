<?php

include "koneksi.db.php";
 
$usercheck = $_POST['user'];
$alamat = $_POST['alamat'];
$no_hp = $_POST['no_hp'];
$password = $_POST['pass'];

$stmt = $koneksi->prepare("SELECT id FROM pelanggan WHERE username = ?");
$stmt->bind_param("s", $param_user);
$param_user = $usercheck;
$stmt->execute();
if ($stmt->num_rows == 1) {
 echo "taken";
} else{
  $username = $usercheck;
}
$stmt->close();

if(isset($username)){
$stmt = $koneksi->prepare("INSERT INTO pelanggan (username, password, alamat, no_hp) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $param_username, $param_password, $param_alamat, $param_no_hp);
$param_username = $username;
$param_password = password_hash($password, PASSWORD_DEFAULT);
$param_alamat =$alamat;
$param_no_hp = $no_hp;
$stmt->execute();
$last_id = $koneksi->insert_id;
echo '[' . $last_id . ', "' . $username . '"]';
$stmt->close();
}
?>
<?php

require_once "koneksi.db.php";
 
$usercheck = $_POST['user'];
$password = $_POST['pass'];

$stmt = $koneksi->prepare("SELECT id,username,password,alamat,no_hp FROM pelanggan WHERE username = ?");
$stmt->bind_param("s", $param_user);
$param_user = $usercheck;
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($id,$username,$alamat,$no_hp, $hashed_password);
if ($stmt->num_rows == 1) {

while($stmt->fetch()) {
if(password_verify($password, $hashed_password)){
$username = $usercheck;
} else {
echo "Invalid password";
}
}
} else{
echo "Invalid username";
}
$stmt->close();

if(isset($username)){
$stmt = $koneksi->prepare("DELETE FROM pelanggan WHERE username = ?");
$stmt->bind_param("s", $param_user);
$param_user = $username;
if ($stmt->execute()) {
echo "user: " . $username . " deleted";
} else {
echo "Delete Failed";
}
}
$stmt->close();
$koneksi->close();
?>
<?php

require_once "koneksi.db.php";
 
$usercheck = $_POST['user'];
$password = $_POST['pass'];
$newpassword = $_POST['newpass'];

$stmt = $koneksi->prepare("SELECT password FROM pelanggan WHERE username = ?");
$stmt->bind_param("s", $param_user);
$param_user = $usercheck;
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($hashed_password);
if ($stmt->num_rows == 1) {
while($stmt->fetch()) {
if(password_verify($password, $hashed_password)){
$username = $usercheck;
} else {
echo "Invalid password";
}
}
} else{
echo "Invalid username";
}
$stmt->close();

if(isset($username)){
$stmt = $koneksi->prepare("UPDATE pelanggan SET password = ? WHERE username = ?");
$stmt -> bind_param("ss", $param_newpassword, $param_user);
$param_newpassword = password_hash($newpassword, PASSWORD_DEFAULT);
$param_user = $username;
$stmt->execute();

if($stmt->affected_rows == 1){
echo "password updated";
} else {
echo "update failed";
}

$stmt->close();
$koneksi->close();
}
?>
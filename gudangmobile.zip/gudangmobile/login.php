<?php

require_once "koneksi.db.php";
 
$username = $_POST['user'];
$password = $_POST['pass'];

$stmt = $koneksi->prepare("SELECT username,password FROM pegawai WHERE username = ?");
$stmt->bind_param("s", $param_user);
$param_user = $username;
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($username, $db_password);
if ($stmt->num_rows == 1) {

while($stmt->fetch()) {
if($password == $db_password){
echo "logged";
} else {
echo "Invalid password";
}
}
} else{
echo "Invalid username";
}
$stmt->close();

?>